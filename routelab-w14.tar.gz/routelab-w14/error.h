#ifndef _error
#define _error

struct GeneralException {};

#endif
